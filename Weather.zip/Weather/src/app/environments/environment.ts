export const environment = {
    production: false,
    weatherApiBaseUrl : 'https://openweather43.p.rapidapi.com/weather',
    XRapidAPIHostHeaderName : 'X-RapidAPI-Host',
    XRapidAPIHostValue : 'openweather43.p.rapidapi.com',

    XRapidAPIKeyHeaderName : 'X-RapidAPI-Key',
    //XRapidAPIKeyValue : 'd57a1563acmsh08c766c5ce7c24ep152d60jsnf00b097cf3e5',
    XRapidAPIKeyValue : 'd57a1563acmsh08c766c5ce7c24ep152d60jsnf00b097cf3e5',


  };