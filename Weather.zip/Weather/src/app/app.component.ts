import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { WeatherService } from './services/weather.service';
import { WeatherData } from './modules/weather.modules';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule,HttpClientModule,FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  constructor(private weatherService : WeatherService){

  }
  cityName : string = 'Paris'
  weatherData ?: WeatherData; 
  ngOnInit(): void {
    this.getWeatherData(this.cityName);
    this.cityName = ''
  }
  onSunmit(){
    this.getWeatherData(this.cityName);
    this.cityName = '';
  }
  private getWeatherData (cityName : string){
    
    this.weatherService.getWeatherData(cityName).subscribe({
      next: (response) => {
        
        this.weatherData = response;
        console.log(response);
      }
    })
  }
}
